var searchData=
[
  ['value_1352',['Value',['../structOPTIONAL__VALUE.html#a132bb9f5252ea6ea862d8834427ee241',1,'OPTIONAL_VALUE']]],
  ['valueptr_1353',['ValuePtr',['../structOPTIONAL__VALUE.html#a9eb3e17f5130070d6283519bcc9f9a50',1,'OPTIONAL_VALUE']]],
  ['voidstar2addrint_1354',['VoidStar2Addrint',['../group__UTILS.html#ga39df8e1146f66f7b89d5d96a7b96e7ff',1,'VoidStar2Addrint(const VOID *addr):&#160;util.PH'],['../group__UTILS.html#gad3aea086a8987032563854094f2b44d1',1,'VoidStar2Addrint(VOID *addr):&#160;util.PH']]],
  ['vstate_1355',['VSTATE',['../structFPSTATE_1_1VSTATE.html',1,'FPSTATE']]],
  ['vstate_5fpadding_1356',['VSTATE_PADDING',['../group__CONTEXT.html#gad1b665d43ed8655d42cf86e474ceb5ea',1,'VSTATE_PADDING():&#160;fpstate_ia32.PH'],['../group__CONTEXT.html#gad1b665d43ed8655d42cf86e474ceb5ea',1,'VSTATE_PADDING():&#160;fpstate_ia32e.PH']]],
  ['vsyscall_5fnr_1357',['VSYSCALL_NR',['../group__INS__INSPECTION.html#ga5da3b48943c5402e8abfe5876525529c',1,'ins.PH']]]
];
