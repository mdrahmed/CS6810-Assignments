var searchData=
[
  ['knob_5fbase_1714',['KNOB_BASE',['../group__KNOBS.html#gae687bfe5eaee90493c5ebb582da31f74',1,'KNOB_BASE']]]
];
