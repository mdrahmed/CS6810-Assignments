var searchData=
[
  ['reg_5fclass_5fbits_2237',['REG_CLASS_BITS',['../group__REG.html#gacc9b609b842ce486cfbb57e95853fdae',1,'reginfo_ia32.PH']]],
  ['regset_2238',['REGSET',['../group__REG.html#ga8a33ca031ce83cf24d58dca8adf19f6c',1,'regset_ia32.PH']]],
  ['remove_5finstrumentation_5fcallback_2239',['REMOVE_INSTRUMENTATION_CALLBACK',['../group__PIN__CONTROL.html#gabd9a69f9525e3ff6b422dabd230cf63c',1,'pin_client.PH']]],
  ['root_5fthread_5ffunc_2240',['ROOT_THREAD_FUNC',['../group__THREADS.html#gaf7d4b7206749ac3075b941a513d876c5',1,'types_vmapi.PH']]],
  ['rtn_5finstrument_5fcallback_2241',['RTN_INSTRUMENT_CALLBACK',['../group__RTN.html#gafc6d6cdd1f6c3b8a2d87081c0fb65b22',1,'pin_client.PH']]]
];
