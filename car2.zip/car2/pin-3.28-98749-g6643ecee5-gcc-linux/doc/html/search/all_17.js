var searchData=
[
  ['xed_5fdecode_5fcallback_1360',['XED_DECODE_CALLBACK',['../group__PIN__CONTROL.html#ga4583560de9d18cb8f1b138e7a91f0666',1,'ins_api_xed_ia32.PH']]],
  ['xsave_5fheader_1361',['XSAVE_HEADER',['../structXSAVE__HEADER.html',1,'']]],
  ['xstate_1362',['XSTATE',['../structFPSTATE_1_1XSTATE.html',1,'FPSTATE']]]
];
