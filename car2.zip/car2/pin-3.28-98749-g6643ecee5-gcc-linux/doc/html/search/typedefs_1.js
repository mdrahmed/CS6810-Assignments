var searchData=
[
  ['buffer_5fid_2200',['BUFFER_ID',['../group__BUFFER.html#gaee232a4179b4897b5869a6d5fc98d032',1,'types_vmapi.PH']]]
];
