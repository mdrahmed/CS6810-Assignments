var searchData=
[
  ['fast_20buffering_20apis_2703',['Fast Buffering APIs',['../group__BUFFER.html',1,'']]]
];
