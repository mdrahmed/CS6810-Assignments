var searchData=
[
  ['set_5femulated_5fregister_5fcallback_2242',['SET_EMULATED_REGISTER_CALLBACK',['../group__APPDEBUG.html#gacb569f5ec458c0cdacfbc511e8d7a24b',1,'debugger_client.PH']]],
  ['smc_5fcallback_2243',['SMC_CALLBACK',['../group__TRACE.html#gad80d434b4df6285334079c19df32a2e8',1,'pin_client.PH']]],
  ['syscall_5fentry_5fcallback_2244',['SYSCALL_ENTRY_CALLBACK',['../group__SYSCALL.html#gab34ef13ce96444da49a29c28f2893b21',1,'pin_client.PH']]],
  ['syscall_5fexit_5fcallback_2245',['SYSCALL_EXIT_CALLBACK',['../group__SYSCALL.html#ga47febb06d8fd5728e7ccba121b8ab56f',1,'pin_client.PH']]]
];
