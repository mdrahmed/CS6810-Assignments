var searchData=
[
  ['reg_3a_20register_20object_2724',['REG: Register Object',['../group__REG.html',1,'']]],
  ['replay_2725',['REPLAY',['../group__REPLAY.html',1,'']]],
  ['rtn_3a_20routine_20object_2726',['RTN: Routine Object',['../group__RTN.html',1,'']]]
];
