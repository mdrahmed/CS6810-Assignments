var searchData=
[
  ['level_5fbase_1428',['LEVEL_BASE',['../namespaceLEVEL__BASE.html',1,'']]]
];
