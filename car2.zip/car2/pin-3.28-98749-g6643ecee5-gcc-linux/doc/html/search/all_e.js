var searchData=
[
  ['native_625',['native',['../structCALL__APPLICATION__FUNCTION__PARAM.html#acc98ab4c8cf0f5ae1b671aa3a610de34',1,'CALL_APPLICATION_FUNCTION_PARAM']]],
  ['no_5fsymbols_626',['NO_SYMBOLS',['../group__PIN__CONTROL.html#gga32ad8725a818ddded04963a3b35a317ca638dc98de833dc4037e14bc6b0e2293d',1,'image.PH']]],
  ['num_5fcontext_5fint_5fregs_627',['NUM_CONTEXT_INT_REGS',['../group__CONTEXT.html#gab6031aa9d9115234b9c49c6d5ab6d9fa',1,'reg_ia32.PH']]],
  ['num_5fcontext_5fregs_628',['NUM_CONTEXT_REGS',['../group__CONTEXT.html#ga565196a3eaf9539660ef24845ca8c967',1,'reg_ia32.PH']]],
  ['num_5fspecial_5fregs_629',['NUM_SPECIAL_REGS',['../group__CONTEXT.html#gaead9b5f2f3655bbaf2776ad99e2ad279',1,'reg_ia32.PH']]],
  ['num_5ftile_5fand_5fcfg_5fregs_630',['NUM_TILE_AND_CFG_REGS',['../group__CONTEXT.html#ga67017a2889bb2234e34bd3a943c94bfe',1,'reg_ia32.PH']]],
  ['num_5ftile_5fregs_631',['NUM_TILE_REGS',['../group__CONTEXT.html#ga47e2bd8a7244f986c5a007bd7070f851',1,'reg_ia32.PH']]],
  ['numberofknobs_632',['NumberOfKnobs',['../group__KNOBS.html#ga6ea4921d7034f43bb963f4f90b6399dc',1,'KNOB_BASE']]],
  ['numofelements_633',['NumOfElements',['../classIMULTI__ELEMENT__OPERAND.html#a9540e7ff0b5c79096a2b2dc62d7ff8e9',1,'IMULTI_ELEMENT_OPERAND::NumOfElements()'],['../classISCATTERED__MEMORY__REWRITE.html#ad98e8ac391d205490dbe82b2a61c095b',1,'ISCATTERED_MEMORY_REWRITE::NumOfElements()']]]
];
