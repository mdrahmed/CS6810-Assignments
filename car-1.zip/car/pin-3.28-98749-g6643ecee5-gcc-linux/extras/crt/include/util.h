/*
 * Copyright (C) 2005-2015 Intel Corporation.
 * SPDX-License-Identifier: MIT
 */

